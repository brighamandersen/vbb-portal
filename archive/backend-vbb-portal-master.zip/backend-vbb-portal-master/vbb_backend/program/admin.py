from django.contrib import admin

from vbb_backend.program.models import Program

admin.site.register(Program)
